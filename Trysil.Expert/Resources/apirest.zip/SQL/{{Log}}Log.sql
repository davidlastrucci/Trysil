/* Schema
*/
CREATE SCHEMA log
GO

/* LogActions
*/
CREATE SEQUENCE log.ActionsID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE log.Actions(
  ID int NOT NULL,
  TaskID nvarchar(50) NOT NULL,
  Date datetime NOT NULL,
  Action nvarchar(255) NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_LogActions PRIMARY KEY CLUSTERED (ID ASC)
);

/* LogRequests
*/
CREATE SEQUENCE log.RequestsID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE log.Requests(
  ID int NOT NULL,
  TaskID nvarchar(50) NOT NULL,
  Date datetime NOT NULL,
  Uri nvarchar(255) NOT NULL,
  Params nvarchar(max) NULL,
  MethodType nvarchar(255) NOT NULL,
  Content nvarchar(max) NULL,
  Headers nvarchar(max) NULL,
  RemoteIP nvarchar(255) NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_LogRequests PRIMARY KEY CLUSTERED (ID ASC)
);

/* LogResponses
*/
CREATE SEQUENCE log.ResponsesID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE log.Responses(
  ID int NOT NULL,
  TaskID nvarchar(50) NOT NULL,
  Date datetime NOT NULL,
  Username nvarchar(255) NOT NULL,
  UserAreas nvarchar(max) NULL,
  StatusCode smallint NOT NULL,
  ContentType nvarchar(255) NOT NULL,
  ContentEncoding nvarchar(255) NOT NULL,
  Content nvarchar(max) NULL,
  BinaryContent nvarchar(max) NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_LogResponses PRIMARY KEY CLUSTERED (ID ASC)
);
