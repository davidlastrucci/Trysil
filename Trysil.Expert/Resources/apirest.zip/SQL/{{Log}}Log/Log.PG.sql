CREATE SEQUENCE Log_ActionsID START 1;

CREATE TABLE Log_Actions(
  ID integer NOT NULL,
  TaskID varchar(50) NOT NULL,
  Date timestamp NOT NULL,
  Action varchar(255) NOT NULL,
  VersionID integer NOT NULL,
  PRIMARY KEY (ID)
);

CREATE SEQUENCE Log_RequestsID START 1;

CREATE TABLE Log_Requests(
  ID integer NOT NULL,
  TaskID varchar(50) NOT NULL,
  Host varchar(255) NOT NULL,
  Date timestamp NOT NULL,
  Uri varchar(255) NOT NULL,
  Params varchar NULL,
  MethodType varchar(50) NOT NULL,
  Content varchar NULL,
  Headers varchar NULL,
  RemoteIP varchar(50) NOT NULL,
  VersionID integer NOT NULL,
  PRIMARY KEY (ID)
);

CREATE SEQUENCE Log_ResponsesID START 1;

CREATE TABLE Log_Responses(
  ID integer NOT NULL,
  TaskID varchar(50) NOT NULL,
  Date timestamp NOT NULL,
  Username varchar(255) NOT NULL,
  UserAreas varchar NULL,
  StatusCode integer NOT NULL,
  ContentType varchar(255) NOT NULL,
  ContentEncoding varchar(255) NOT NULL,
  Content varchar NULL,
  BinaryContent varchar NULL,
  VersionID integer NOT NULL,
  PRIMARY KEY (ID)
);

