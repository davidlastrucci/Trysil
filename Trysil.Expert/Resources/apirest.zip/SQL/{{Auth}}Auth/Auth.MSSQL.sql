CREATE SEQUENCE Auth_AreasID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE Auth_Areas(
  ID int NOT NULL,
  Description nvarchar(100) NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_Auth_Areas PRIMARY KEY CLUSTERED (ID ASC)
);

CREATE SEQUENCE Auth_UsersID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE Auth_Users(
  ID int NOT NULL,
  Firstname nvarchar(100) NOT NULL,
  Lastname nvarchar(100) NOT NULL,
  UserTypeID int NOT NULL,
  Username nvarchar(255) NOT NULL,
  Password nvarchar(255) NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_Auth_Users PRIMARY KEY CLUSTERED (ID ASC)
);

CREATE SEQUENCE Auth_UserTypesID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE Auth_UserTypes(
  ID int NOT NULL,
  Description nvarchar(100) NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_Auth_UserTypes PRIMARY KEY CLUSTERED (ID ASC)
);

CREATE SEQUENCE Auth_UserTypesAreasID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE Auth_UserTypesAreas(
  ID int NOT NULL,
  UserTypeID int NOT NULL,
  AreaID int NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_Auth_UserTypesAreas PRIMARY KEY CLUSTERED (ID ASC)
);

