CREATE SEQUENCE Auth_AreasID START 1;

CREATE TABLE Auth_Areas(
  ID integer NOT NULL,
  Description varchar(100) NOT NULL,
  VersionID integer NOT NULL,
  PRIMARY KEY (ID)
);

CREATE SEQUENCE Auth_UsersID START 1;

CREATE TABLE Auth_Users(
  ID integer NOT NULL,
  Firstname varchar(100) NOT NULL,
  Lastname varchar(100) NOT NULL,
  UserTypeID integer NOT NULL,
  Username varchar(255) NOT NULL,
  Password varchar(255) NOT NULL,
  VersionID integer NOT NULL,
  PRIMARY KEY (ID)
);

CREATE SEQUENCE Auth_UserTypesID START 1;

CREATE TABLE Auth_UserTypes(
  ID integer NOT NULL,
  Description varchar(100) NOT NULL,
  VersionID integer NOT NULL,
  PRIMARY KEY (ID)
);

CREATE SEQUENCE Auth_UserTypesAreasID START 1;

CREATE TABLE Auth_UserTypesAreas(
  ID integer NOT NULL,
  UserTypeID integer NOT NULL,
  AreaID integer NOT NULL,
  VersionID integer NOT NULL,
  PRIMARY KEY (ID)
);

