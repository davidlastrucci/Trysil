/* AuthAreas
*/
CREATE SEQUENCE AuthAreasID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE AuthAreas(
  ID int NOT NULL,
  Name nvarchar(50) NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_Areas PRIMARY KEY CLUSTERED (ID ASC)
);

/* AuthUsers
*/
CREATE SEQUENCE AuthUsersID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE AuthUsers(
  ID int NOT NULL,
  Firstname nvarchar(100) NOT NULL,
  Lastname nvarchar(100) NOT NULL,
  Username nvarchar(255) NOT NULL,
  Password nvarchar(255) NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_Users PRIMARY KEY CLUSTERED (ID ASC)
);

CREATE UNIQUE INDEX IDX_AuthUsers_Username ON AuthUsers (Username);  

/* UserAreas
*/
CREATE SEQUENCE AuthUserAreasID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE AuthUserAreas(
  ID int NOT NULL,
  UserID int NOT NULL,
  AreaID int NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_UserAreas PRIMARY KEY CLUSTERED (ID ASC)
);

CREATE INDEX IDX_AuthUserAreas_UserID ON AuthUserAreas (UserID);  
