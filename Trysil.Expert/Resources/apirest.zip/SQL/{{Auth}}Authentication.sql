/* Schema
*/
CREATE SCHEMA auth
GO

/* Areas
*/
CREATE SEQUENCE auth.AreasID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE auth.Areas(
  ID int NOT NULL,
  Name nvarchar(50) NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_Areas PRIMARY KEY CLUSTERED (ID ASC)
);

/* Users
*/
CREATE SEQUENCE auth.UsersID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE auth.Users(
  ID int NOT NULL,
  Firstname nvarchar(100) NOT NULL,
  Lastname nvarchar(100) NOT NULL,
  Username nvarchar(255) NOT NULL,
  Password nvarchar(255) NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_Users PRIMARY KEY CLUSTERED (ID ASC)
);

CREATE UNIQUE INDEX IDX_Users_Username ON auth.Users (Username);  

/* UserAreas
*/
CREATE SEQUENCE auth.UserAreasID
  AS int
  START WITH 1
  INCREMENT BY 1;

CREATE TABLE auth.UserAreas(
  ID int NOT NULL,
  UserID int NOT NULL,
  AreaID int NOT NULL,
  VersionID int NOT NULL,
  CONSTRAINT PK_UserAreas PRIMARY KEY CLUSTERED (ID ASC)
);

CREATE INDEX IDX_UserAreas_UserID ON auth.UserAreas (UserID);  
